#!/usr/bin/env python3
"""
SongForge AI — desktop app (local web UI via Gradio).

Run this, and it opens a real app in your browser at http://127.0.0.1:7860 —
upload a song, set the sliders, hit the button, get back a processed file.
Everything still runs locally; nothing is uploaded anywhere.
"""

import multiprocessing
import os
import tempfile

import gradio as gr
import webview

from songforge import make_over, STYLES
from prompt_parser import parse_prompt, suggest_prompt

STYLE_LABELS = {
    "original": "Preserve original",
    "emorap": "Underground / emo-rap",
    "drill": "Drill / dark trap",
    "lofi": "Lo-fi",
    "modern": "Modern / clean rap",
    "cinematic": "Cinematic / dark",
}
LABEL_TO_STYLE = {v: k for k, v in STYLE_LABELS.items()}


STAGE_FRACS = {
    "[1/5]": 0.05,
    "[2/5]": 0.25,
    "[3/5]": 0.60,
    "[4/5]": 0.75,
    "[5/5]": 0.92,
}
STEM_ORDER = ["vocals", "drums", "bass", "other"]


def run(song_path, prompt_text, style_label, makeover, identity, device, keep_stems,
        progress=gr.Progress()):
    if song_path is None:
        raise gr.Error("Upload a song first.")

    log_lines = []

    if prompt_text and prompt_text.strip():
        parsed = parse_prompt(prompt_text)
        style = parsed["style"]
        makeover = parsed["makeover"]
        identity = parsed["identity"]
        log_lines.append(
            f"Interpreted your prompt as: style='{STYLE_LABELS[style]}', "
            f"makeover={makeover:.0f}%, identity={identity:.0f}% "
            "(edit the sliders below and clear the prompt if this isn't right)."
        )
    else:
        style = LABEL_TO_STYLE[style_label]

    out_dir = tempfile.mkdtemp(prefix="songforge_out_")
    base = os.path.splitext(os.path.basename(song_path))[0]
    out_path = os.path.join(out_dir, f"{base}_makeover.wav")

    progress(0, desc="Starting...")

    def progress_cb(msg):
        log_lines.append(msg)
        frac = None
        for key, f in STAGE_FRACS.items():
            if msg.startswith(key):
                frac = f
        stripped = msg.strip()
        if stripped.startswith("-> "):
            stem = stripped[3:]
            if stem in STEM_ORDER:
                idx = STEM_ORDER.index(stem)
                frac = 0.25 + (idx + 1) / len(STEM_ORDER) * 0.30
        if frac is not None:
            progress(frac, desc=stripped)

    make_over(
        song_path, out_path,
        style=style, makeover=makeover, identity=identity,
        device=device, keep_stems=keep_stems, progress=progress_cb,
    )
    progress(1.0, desc="Done")

    return out_path, "\n".join(log_lines)


with gr.Blocks(title="SongForge AI") as demo:
    gr.Markdown(
        "# SongForge AI\n"
        "Upload a rough recording. Real Demucs stem separation + reconstruction "
        "runs on your machine and gives you back a processed version."
    )
    with gr.Row():
        with gr.Column():
            song_in = gr.Audio(type="filepath", label="Your song")
            with gr.Row():
                prompt_in = gr.Textbox(
                    label="Describe how you want it to sound (optional)",
                    placeholder="e.g. dark and raw, keep my vocal imperfections, hit hard on the low end",
                    scale=4,
                )
                suggest_btn = gr.Button("🎲 Suggest a prompt", scale=1)
            gr.Markdown(
                "_If you fill this in, it overrides the style/sliders below. "
                "Leave it blank to control those manually._"
            )
            style_in = gr.Dropdown(
                choices=list(STYLE_LABELS.values()),
                value=STYLE_LABELS["emorap"], label="Style",
            )
            makeover_in = gr.Slider(0, 100, value=60, label="Makeover amount")
            identity_in = gr.Slider(0, 100, value=75, label="Identity preservation")
            device_in = gr.Radio(["cpu", "cuda"], value="cpu", label="Device")
            keep_stems_in = gr.Checkbox(label="Also give me the separated stems")
            run_btn = gr.Button("CREATE MAKEOVER", variant="primary")
        with gr.Column():
            song_out = gr.Audio(label="Makeover result", type="filepath")
            log_out = gr.Textbox(label="Progress log", lines=10)

    suggest_btn.click(suggest_prompt, outputs=prompt_in)

    run_btn.click(
        run,
        inputs=[song_in, prompt_in, style_in, makeover_in, identity_in, device_in, keep_stems_in],
        outputs=[song_out, log_out],
    )

if __name__ == "__main__":
    multiprocessing.freeze_support()
    # Start the Gradio server in the background (no browser tab)...
    demo.launch(inbrowser=False, prevent_thread_lock=True, quiet=True)
    # ...and show it inside a real desktop window instead.
    webview.create_window("SongForge AI", "http://127.0.0.1:7860", width=1100, height=850)
    webview.start()
    demo.close()
