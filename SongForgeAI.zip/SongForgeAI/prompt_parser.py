"""
Turns a free-text description ("dark and raw, keep my vocal imperfections")
into style/makeover/identity settings.

This is a simple local keyword matcher, not a language model — it runs
instantly, offline, with no API calls. It's meant to get you close; the
sliders/dropdown in the app still let you fine-tune or override whatever
it guesses.
"""

import random

KEYWORDS = {
    "emorap": ["emo", "underground", "raw", "gritty", "vulnerable", "hurt",
               "pain", "sad", "melancholy", "juice wrld", "king von", "tired",
               "aching", "honest"],
    "drill": ["drill", "aggressive", "hard", "menacing", "trap", "intense",
              "grimy", "dark trap", "sinister"],
    "lofi": ["lofi", "lo-fi", "chill", "cassette", "tape", "dusty", "mellow",
             "nostalgic", "warm and worn", "bedroom"],
    "modern": ["clean", "polished", "commercial", "radio", "bright", "crisp",
               "professional", "pop", "shiny"],
    "cinematic": ["cinematic", "epic", "orchestral", "atmospheric", "moody",
                  "widescreen", "dramatic", "spacious"],
    "original": ["untouched", "natural", "minimal", "barely touch",
                 "don't change", "keep it real", "as close to the original"],
}

INTENSITY_UP = ["a lot", "heavy", "max", "maximum", "full", "extreme",
                "loud", "big", "huge", "massive", "pump it up", "really change"]
INTENSITY_DOWN = ["subtle", "light", "gentle", "slight", "a little", "barely",
                   "minimal", "soft touch", "just a bit"]

PRESERVE_UP = ["preserve", "keep my vocals", "don't lose", "stay true",
               "keep it raw", "keep the imperfections", "authentic",
               "real performance", "still sound like me"]
PRESERVE_DOWN = ["rebuild", "overhaul", "completely change", "transform",
                  "reinvent", "go all out"]

EXAMPLE_PROMPTS = [
    "Make it sound like it was recorded alone at 2am — raw and underground, "
    "but professionally mixed. Keep my vocal imperfections.",
    "Dark and heavy, like a King Von record — punchy drums, deep bass, "
    "keep the grit in my voice.",
    "Clean this up a lot but don't touch my performance — subtle, "
    "professional, still sounds like me.",
    "Lo-fi and dusty, warm tape feel, mellow and a little worn down.",
    "Cinematic and moody, wide and atmospheric, like it's building toward "
    "something.",
    "Barely touch it, just fix the obvious problems, keep it as close to "
    "the original as possible.",
    "Big drill energy, aggressive, hard-hitting bass, menacing.",
    "Modernize it — bright, crisp, radio-ready, but don't lose the emotion.",
]


def parse_prompt(text):
    t = text.lower()
    scores = {k: 0 for k in KEYWORDS}
    for style, words in KEYWORDS.items():
        for w in words:
            if w in t:
                scores[style] += 1
    style = max(scores, key=scores.get) if any(scores.values()) else "emorap"

    makeover = 60
    for w in INTENSITY_UP:
        if w in t:
            makeover += 12
    for w in INTENSITY_DOWN:
        if w in t:
            makeover -= 12
    makeover = max(0, min(100, makeover))

    identity = 75
    for w in PRESERVE_UP:
        if w in t:
            identity += 10
    for w in PRESERVE_DOWN:
        if w in t:
            identity -= 15
    identity = max(0, min(100, identity))

    return {"style": style, "makeover": makeover, "identity": identity}


def suggest_prompt():
    return random.choice(EXAMPLE_PROMPTS)
