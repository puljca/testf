#!/usr/bin/env python3
"""
SongForge AI — local edition.

Real pipeline:
  1. Neural stem separation (Demucs, htdemucs model) -> vocals / drums / bass / other
  2. Per-stem AI-style processing (EQ, compression, de-noise, saturation, transient shaping)
  3. Style-aware remix of the stems
  4. Master bus processing (EQ, glue compression, stereo width, reverb, limiter, loudness match)

Everything runs on your machine. First run will download the Demucs model (~80-300MB
depending on model) from its official source the first time you use it.

Usage:
  python songforge.py input.wav --style emorap --makeover 65 --identity 75 -o makeover.wav

See README.md for setup.
"""

import argparse
import os
import shutil
import subprocess
import sys
import tempfile

import numpy as np
import soundfile as sf
from scipy.signal import lfilter, fftconvolve

try:
    import noisereduce as nr
    HAVE_NOISEREDUCE = True
except ImportError:
    HAVE_NOISEREDUCE = False

try:
    import pyloudnorm as pyln
    HAVE_LOUDNORM = True
except ImportError:
    HAVE_LOUDNORM = False


# ---------------------------------------------------------------- I/O -----

def read_audio(path):
    audio, sr = sf.read(path, always_2d=True, dtype="float32")
    if audio.shape[1] == 1:
        audio = np.repeat(audio, 2, axis=1)
    return audio, sr


def write_audio(path, audio, sr):
    sf.write(path, np.clip(audio, -1.0, 1.0), sr, subtype="PCM_24")


# ------------------------------------------------------- stem separation --

def separate_stems(input_path, work_dir, model="htdemucs", device="cpu"):
    """Run real Demucs source separation. Returns dict of stem name -> wav path."""
    print("  -> calling Demucs (neural source separation)...")
    cmd = [
        "demucs", "-n", model, "-d", device,
        "-o", work_dir, input_path,
    ]
    try:
        subprocess.run(cmd, check=True)
    except FileNotFoundError:
        sys.exit(
            "ERROR: the 'demucs' command was not found.\n"
            "Install it first:  pip install demucs\n"
            "(this also installs torch/torchaudio if you don't have them)"
        )
    except subprocess.CalledProcessError as e:
        sys.exit(f"ERROR: demucs failed ({e}).")

    track_name = os.path.splitext(os.path.basename(input_path))[0]
    stem_dir = os.path.join(work_dir, model, track_name)
    stems = {}
    for name in ["vocals", "drums", "bass", "other"]:
        p = os.path.join(stem_dir, f"{name}.wav")
        if not os.path.exists(p):
            sys.exit(f"ERROR: expected stem file missing: {p}")
        stems[name] = p
    return stems


# --------------------------------------------------------- DSP building blocks

def analyze(audio):
    peak = float(np.max(np.abs(audio))) or 1e-6
    rms = float(np.sqrt(np.mean(audio ** 2))) or 1e-6
    return {
        "peak_db": 20 * np.log10(peak),
        "rms_db": 20 * np.log10(rms),
        "dyn_range": 20 * np.log10(peak) - 20 * np.log10(rms),
    }


def _peak_biquad(sr, freq, gain_db, q=0.9):
    A = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * freq / sr
    alpha = np.sin(w0) / (2 * q)
    b0 = 1 + alpha * A
    b1 = -2 * np.cos(w0)
    b2 = 1 - alpha * A
    a0 = 1 + alpha / A
    a1 = -2 * np.cos(w0)
    a2 = 1 - alpha / A
    return np.array([b0, b1, b2]) / a0, np.array([a0, a1, a2]) / a0


def _shelf_biquad(sr, freq, gain_db, kind="low"):
    A = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * freq / sr
    alpha = np.sin(w0) / 2 * np.sqrt((A + 1 / A) * 1.0 + 2)  # S=1 shelf slope
    sqrtA = np.sqrt(A)
    cosw0 = np.cos(w0)
    if kind == "low":
        b0 = A * ((A + 1) - (A - 1) * cosw0 + 2 * sqrtA * alpha)
        b1 = 2 * A * ((A - 1) - (A + 1) * cosw0)
        b2 = A * ((A + 1) - (A - 1) * cosw0 - 2 * sqrtA * alpha)
        a0 = (A + 1) + (A - 1) * cosw0 + 2 * sqrtA * alpha
        a1 = -2 * ((A - 1) + (A + 1) * cosw0)
        a2 = (A + 1) + (A - 1) * cosw0 - 2 * sqrtA * alpha
    else:
        b0 = A * ((A + 1) + (A - 1) * cosw0 + 2 * sqrtA * alpha)
        b1 = -2 * A * ((A - 1) + (A + 1) * cosw0)
        b2 = A * ((A + 1) + (A - 1) * cosw0 - 2 * sqrtA * alpha)
        a0 = (A + 1) - (A - 1) * cosw0 + 2 * sqrtA * alpha
        a1 = 2 * ((A - 1) - (A + 1) * cosw0)
        a2 = (A + 1) - (A - 1) * cosw0 - 2 * sqrtA * alpha
    return np.array([b0, b1, b2]) / a0, np.array([a0, a1, a2]) / a0


def apply_eq(audio, sr, low_gain, mid_gain, high_gain,
             low_f=90, mid_f=2500, high_f=9000):
    out = audio.copy()
    for ch in range(out.shape[1]):
        x = out[:, ch]
        if abs(low_gain) > 0.05:
            b, a = _shelf_biquad(sr, low_f, low_gain, "low")
            x = lfilter(b, a, x)
        if abs(mid_gain) > 0.05:
            b, a = _peak_biquad(sr, mid_f, mid_gain)
            x = lfilter(b, a, x)
        if abs(high_gain) > 0.05:
            b, a = _shelf_biquad(sr, high_f, high_gain, "high")
            x = lfilter(b, a, x)
        out[:, ch] = x
    return out


def envelope_follower(x, sr, attack_ms, release_ms):
    a_coef = np.exp(-1.0 / (sr * attack_ms / 1000.0))
    r_coef = np.exp(-1.0 / (sr * release_ms / 1000.0))
    env = np.zeros_like(x)
    level = 0.0
    ax = np.abs(x)
    for i in range(len(x)):
        v = ax[i]
        coef = a_coef if v > level else r_coef
        level = coef * level + (1 - coef) * v
        env[i] = level
    return env


def compress(audio, sr, threshold_db=-24, ratio=4, attack_ms=6,
             release_ms=180, makeup_db=0):
    out = audio.copy()
    for ch in range(out.shape[1]):
        x = out[:, ch]
        env = envelope_follower(x, sr, attack_ms, release_ms)
        env_db = 20 * np.log10(np.maximum(env, 1e-6))
        over = np.maximum(0, env_db - threshold_db)
        gain_reduction_db = -over * (1 - 1 / ratio)
        gain = 10 ** ((gain_reduction_db + makeup_db) / 20)
        out[:, ch] = x * gain
    return out


def limiter(audio, ceiling_db=-0.8):
    out = audio.copy()
    ceiling = 10 ** (ceiling_db / 20)
    peak = np.max(np.abs(out))
    if peak > ceiling:
        out *= ceiling / peak
    # fast look-ahead-ish smoothing to tame residual transients
    for ch in range(out.shape[1]):
        x = out[:, ch]
        over = np.abs(x) > ceiling
        if np.any(over):
            x[over] = np.sign(x[over]) * ceiling
        out[:, ch] = x
    return out


def saturate(audio, drive):
    if drive <= 0:
        return audio
    return np.tanh(audio * (1 + drive * 5)) / np.tanh(1 + drive * 5)


def synthetic_reverb(audio, sr, seconds=1.8, decay=2.2, mix=0.15):
    if mix <= 0:
        return audio
    length = int(sr * seconds)
    envelope = ((1 - np.arange(length) / length) ** decay)[:, None]
    ir = (np.random.randn(length, 2) * envelope).astype(np.float32)
    wet = np.zeros_like(audio)
    for ch in range(audio.shape[1]):
        conv = fftconvolve(audio[:, ch], ir[:, ch % ir.shape[1]])[: audio.shape[0]]
        wet[:, ch] = conv
    peak = np.max(np.abs(wet)) or 1
    wet = wet / peak * (np.max(np.abs(audio)) or 1)
    return audio * (1 - mix) + wet * mix


def stereo_widen(audio, amount):
    if amount <= 0:
        return audio
    mid = (audio[:, 0] + audio[:, 1]) / 2
    side = (audio[:, 0] - audio[:, 1]) / 2 * (1 + amount)
    out = np.zeros_like(audio)
    out[:, 0] = mid + side
    out[:, 1] = mid - side
    return out


def denoise_vocal(audio, sr):
    if not HAVE_NOISEREDUCE:
        return audio
    out = audio.copy()
    for ch in range(out.shape[1]):
        out[:, ch] = nr.reduce_noise(y=out[:, ch], sr=sr, prop_decrease=0.6)
    return out


def de_ess(audio, sr, amount):
    """Tame harsh sibilance (5-9kHz) with a fast, high-frequency-only compressor."""
    if amount <= 0:
        return audio
    out = audio.copy()
    for ch in range(out.shape[1]):
        x = out[:, ch]
        b, a = _peak_biquad(sr, 7000, 1.0, q=2.0)
        sibilance = lfilter(b, a, x)
        env = envelope_follower(sibilance, sr, 2, 40)
        reduction = 1 - np.clip((env - 0.05) * amount * 6, 0, 0.6)
        out[:, ch] = x * reduction
    return out


def transient_shape(audio, sr, amount):
    """Punch up drum transients a bit."""
    if amount <= 0:
        return audio
    out = audio.copy()
    for ch in range(out.shape[1]):
        x = out[:, ch]
        fast = envelope_follower(x, sr, 1, 10)
        slow = envelope_follower(x, sr, 30, 120)
        boost = 1 + np.clip(fast - slow, 0, None) * amount * 8
        out[:, ch] = x * boost
    return out


def loudness_normalize(audio, sr, target_lufs=-9.0):
    if not HAVE_LOUDNORM:
        a = analyze(audio)
        target_rms_db = target_lufs + 3
        gain = 10 ** ((target_rms_db - a["rms_db"]) / 20)
        return audio * gain
    meter = pyln.Meter(sr)
    loudness = meter.integrated_loudness(audio)
    return pyln.normalize.loudness(audio, loudness, target_lufs)


# --------------------------------------------------------------- styles ---

# (low_gain_db, mid_gain_db, high_gain_db), comp_ratio_extra, drive, reverb_mix, width
STYLES = {
    "original":  dict(eq=(0, 0, 0), comp=0, drive=0.0, verb=0.05, width=0.0, target_lufs=-12),
    "emorap":    dict(eq=(1.5, -1.5, 1.5), comp=3, drive=0.10, verb=0.16, width=0.20, target_lufs=-9),
    "drill":     dict(eq=(3.0, -2.0, 1.0), comp=4, drive=0.18, verb=0.08, width=0.10, target_lufs=-8),
    "lofi":      dict(eq=(1.0, -3.0, -3.0), comp=1, drive=0.25, verb=0.22, width=0.05, target_lufs=-11),
    "modern":    dict(eq=(1.0, 1.0, 2.0), comp=3, drive=0.08, verb=0.12, width=0.30, target_lufs=-8),
    "cinematic": dict(eq=(2.0, -1.0, 1.0), comp=2, drive=0.03, verb=0.35, width=0.35, target_lufs=-11),
}

STEM_MIX = {
    "original":  dict(vocals=1.0, drums=1.0, bass=1.0, other=1.0),
    "emorap":    dict(vocals=1.15, drums=0.95, bass=1.05, other=0.9),
    "drill":     dict(vocals=1.0, drums=1.1, bass=1.2, other=0.85),
    "lofi":      dict(vocals=0.95, drums=0.85, bass=1.0, other=1.05),
    "modern":    dict(vocals=1.1, drums=1.05, bass=1.05, other=1.0),
    "cinematic": dict(vocals=1.0, drums=0.9, bass=1.0, other=1.2),
}


def process_stem(name, audio, sr, style, intensity):
    s = STYLES[style]
    low, mid, high = [g * intensity for g in s["eq"]]

    if name == "vocals":
        audio = denoise_vocal(audio, sr)
        audio = apply_eq(audio, sr, low * 0.6, mid, high * 1.2)
        audio = de_ess(audio, sr, intensity)
        audio = compress(audio, sr, threshold_db=-22, ratio=3 + s["comp"] * intensity,
                          attack_ms=5, release_ms=150)
    elif name == "drums":
        audio = apply_eq(audio, sr, low * 1.2, mid * 0.5, high * 0.8, low_f=70, high_f=8000)
        audio = transient_shape(audio, sr, intensity)
        audio = compress(audio, sr, threshold_db=-20, ratio=2 + s["comp"] * intensity,
                          attack_ms=3, release_ms=100)
    elif name == "bass":
        audio = apply_eq(audio, sr, low * 1.0, mid * 0.3, high * -0.5, low_f=60, high_f=4000)
        audio = saturate(audio, s["drive"] * intensity)
        audio = compress(audio, sr, threshold_db=-20, ratio=3 + s["comp"] * intensity,
                          attack_ms=8, release_ms=180)
    else:  # other: melodic/harmonic instruments
        audio = apply_eq(audio, sr, low * 0.7, mid, high)
        audio = synthetic_reverb(audio, sr, mix=s["verb"] * intensity)

    return audio


def remix(stems, sr, style, intensity):
    mix_levels = STEM_MIX[style]
    n = max(a.shape[0] for a in stems.values())
    out = np.zeros((n, 2), dtype=np.float32)
    for name, audio in stems.items():
        level = 1 + (mix_levels[name] - 1) * intensity
        padded = np.zeros((n, 2), dtype=np.float32)
        padded[: audio.shape[0]] = audio
        out += padded * level
    return out


def master_bus(audio, sr, style, intensity):
    s = STYLES[style]
    audio = stereo_widen(audio, s["width"] * intensity)
    audio = synthetic_reverb(audio, sr, mix=s["verb"] * intensity * 0.4)
    audio = compress(audio, sr, threshold_db=-14, ratio=1.5 + s["comp"] * intensity * 0.4,
                      attack_ms=10, release_ms=200)
    audio = loudness_normalize(audio, sr, target_lufs=s["target_lufs"])
    audio = limiter(audio, ceiling_db=-0.8)
    return audio


# ------------------------------------------------------------------ main --

def make_over(input_path, output_path, style="emorap", makeover=60, identity=75,
              model="htdemucs", device="cpu", keep_stems=False, progress=print):
    """Run the full pipeline programmatically. `progress(msg)` is called with
    status updates — pass a GUI-aware callback to drive a progress bar."""
    intensity = (makeover / 100) * (1 - (identity / 100) * 0.5)

    work_dir = tempfile.mkdtemp(prefix="songforge_")
    try:
        progress(f"[1/5] Separating stems with Demucs ({model}, {device})...")
        stem_paths = separate_stems(input_path, work_dir, model, device)

        progress("[2/5] Loading stems and reconstructing each part...")
        sr = None
        processed = {}
        for name, path in stem_paths.items():
            audio, sr = read_audio(path)
            progress(f"      -> {name}")
            processed[name] = process_stem(name, audio, sr, style, intensity)

        progress("[3/5] Remixing stems (style-aware balance)...")
        mixed = remix(processed, sr, style, intensity)

        progress("[4/5] Master bus: width, glue compression, loudness, limiting...")
        mastered = master_bus(mixed, sr, style, intensity)

        progress("[5/5] Quality check + export...")
        a_before = analyze(read_audio(input_path)[0])
        a_after = analyze(mastered)
        progress(f"      original loudness ~{a_before['rms_db']:.1f} dBFS RMS")
        progress(f"      makeover loudness ~{a_after['rms_db']:.1f} dBFS RMS")

        write_audio(output_path, mastered, sr)
        progress(f"Done. Wrote {output_path}")

        if keep_stems:
            stems_out = os.path.splitext(output_path)[0] + "_stems"
            os.makedirs(stems_out, exist_ok=True)
            for name, path in stem_paths.items():
                shutil.copy(path, os.path.join(stems_out, f"{name}.wav"))
            progress(f"Stems saved to {stems_out}/")
        return output_path
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser(description="SongForge AI — local stem-separation makeover tool")
    ap.add_argument("input", help="input song file (wav/mp3/flac/aiff/m4a)")
    ap.add_argument("-o", "--output", default="makeover.wav", help="output WAV path")
    ap.add_argument("--style", choices=list(STYLES.keys()), default="emorap")
    ap.add_argument("--makeover", type=float, default=60, help="0-100, overall amount")
    ap.add_argument("--identity", type=float, default=75, help="0-100, how conservative to be")
    ap.add_argument("--model", default="htdemucs", help="demucs model name")
    ap.add_argument("--device", default="cpu", choices=["cpu", "cuda"])
    ap.add_argument("--keep-stems", action="store_true", help="keep separated stem WAVs")
    args = ap.parse_args()

    make_over(args.input, args.output, args.style, args.makeover, args.identity,
              args.model, args.device, args.keep_stems, progress=print)


if __name__ == "__main__":
    main()
