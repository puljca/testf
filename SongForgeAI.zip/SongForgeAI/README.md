# SongForge AI — local edition

This is the real version: it uses **Demucs** (an actual pretrained neural network,
made by Meta AI Research) to split your song into vocals / drums / bass / other,
then runs a DSP reconstruction chain on each part before remixing and mastering.

Nothing here is a mockup — it's genuine source separation, not an approximation.
It runs entirely on your own machine.

## Setup

You need Python 3.9–3.11.

```bash
python -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

This installs `demucs`, which pulls in `torch`/`torchaudio`. On first use, Demucs
downloads its model weights (roughly 80–300MB depending on the model) — that
happens once and is cached locally.

If you have an NVIDIA GPU with CUDA set up, pass `--device cuda` to speed things
up a lot. Otherwise it runs on CPU — expect a few minutes per song, more for
longer tracks.

## Usage — app (recommended)

```bash
python songforge_app.py
```

This opens a real app in your browser at `http://127.0.0.1:7860` — upload a
song, set the style and sliders, hit **CREATE MAKEOVER**, and play or download
the result right there. Everything still runs on your machine; nothing leaves
your computer.

## Usage — command line

```bash
python songforge.py my_song.wav --style emorap --makeover 65 --identity 75 -o my_song_makeover.wav
```

Options:

- `--style` — `original`, `emorap`, `drill`, `lofi`, `modern`, `cinematic`
- `--makeover` — 0–100, how much processing to apply overall
- `--identity` — 0–100, how conservative to keep it (higher = more restrained)
- `--keep-stems` — also save the separated vocals/drums/bass/other as WAVs
- `--model` — demucs model name (default `htdemucs`; `htdemucs_ft` is slower but
  slightly cleaner separation if you want to try it)
- `--device` — `cpu` (default) or `cuda`

## What it actually does

1. **Separation** — Demucs splits the mix into 4 real stems using a trained
   neural network, not an EQ trick.
2. **Vocal reconstruction** — noise reduction, de-essing, EQ, compression.
3. **Drum reconstruction** — transient shaping, EQ, compression.
4. **Bass reconstruction** — EQ, harmonic saturation, compression.
5. **Instrument reconstruction** — EQ and space (reverb).
6. **Remix** — stems are blended back together with style-aware level balance
   (e.g. vocals pushed forward for the underground/emo-rap style).
7. **Master bus** — stereo width, glue compression, loudness normalization
   (LUFS-based if `pyloudnorm` is installed), and a limiter.

## Honest limitations

- Demucs separation is very good but not perfect — on a rough phone recording
  you may hear some bleed between stems or artifacts. That's a real limit of
  current separation models, not something this script can fully hide.
- There's no pitch-correction or AI resynthesis of the vocal itself — it works
  with what's in the original vocal stem, not a rebuilt/cloned voice. This
  keeps your actual performance intact, which was the point.
- Song-section detection (verse/chorus-aware processing) isn't implemented —
  processing is applied uniformly across the whole track for now.

If you want section-aware processing (bigger chorus, more intimate verse)
added next, that's doable with basic energy/repetition-based segmentation —
just ask.
